﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _05.BorderControl
{
    public interface IIdentifiable
    {
        string Id { get; }
    }
}
