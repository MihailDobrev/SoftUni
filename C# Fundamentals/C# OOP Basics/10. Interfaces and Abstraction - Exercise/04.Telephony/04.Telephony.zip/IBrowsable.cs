﻿namespace _04.Telephony
{
    public interface IBrowsable
    {
        string Browse(string site);
    }
}
