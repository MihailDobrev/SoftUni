﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _08.MilitaryElite
{
    public class Private : Soldier, ISoldier
    {
        public Private(int id, string firstName, string lastName, decimal salary) 
            : base(id, firstName, lastName, salary)
        {

        }
    }
}
