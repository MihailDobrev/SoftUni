﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _09.CollectionHierarchy
{
    public class AddCollection:IAddible
    {
        public AddCollection()
        {
            Collection = new List<string>();
        }

        public List<string> Collection { get; set; }

        public int Add(string input)
        {
            int indexToAdd = 0;
            if (Collection.Count>0)
            {
                indexToAdd = Collection.Count;
            }         
            Collection.Insert(indexToAdd,input);
            return indexToAdd;
        }
    }
}
