﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _09.CollectionHierarchy
{
    public interface IAddible
    {
        List<string> Collection { get; }
        int Add(string input);
    }
}
