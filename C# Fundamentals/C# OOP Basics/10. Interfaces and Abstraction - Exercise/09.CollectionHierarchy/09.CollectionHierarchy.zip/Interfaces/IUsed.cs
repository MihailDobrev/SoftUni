﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _09.CollectionHierarchy.Interfaces
{
    public interface IUsed:IRemovable
    {
        int Used { get; }
    }
}
